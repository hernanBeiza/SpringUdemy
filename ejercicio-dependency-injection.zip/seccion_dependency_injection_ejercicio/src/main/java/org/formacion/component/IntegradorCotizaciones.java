package org.formacion.component;

public interface IntegradorCotizaciones {

	public float obtenMediaDiariaCotizaciones();
	
	float obtenCotitzacion(String empresa);
}
