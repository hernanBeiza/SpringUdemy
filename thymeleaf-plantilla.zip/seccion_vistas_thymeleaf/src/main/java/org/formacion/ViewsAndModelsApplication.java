package org.formacion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ViewsAndModelsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ViewsAndModelsApplication.class, args);
	}
}
